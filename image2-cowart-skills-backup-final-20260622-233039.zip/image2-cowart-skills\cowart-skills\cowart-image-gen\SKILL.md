---
name: cowart-image-gen
description: Generate a final AI bitmap for the Cowart canvas with the user's image2-ai/Image2 model, including any requested in-image text by default. Use when the user asks Codex to create, fill, replace, or place an AI-generated image on a Cowart canvas. If an AI 图片 holder is selected, fill that holder; otherwise generate the image with image2-ai, place it on a clean visible Cowart page, and focus the canvas on the result.
---

# Cowart Image Gen

Use this skill when the user wants an AI-generated image placed onto the Cowart canvas. A selected `AI 图片` holder gives a precise size and placement target, but it is not required.

Default posture: keep the flow fast and treat Cowart as an infinite canvas. Do
not force the user to draw a holder for every image. Use a holder only when one
is already selected, when the user explicitly asks for a framed slot, or when
exact frame placement is truly required. Otherwise insert the finished bitmap on
a fresh Cowart page and focus the visible browser on it.

## Preconditions

The Cowart service should be running for the user's active project, usually at:

```text
http://127.0.0.1:43217
```

New holders are tldraw `frame` shapes with:

```json
{
  "type": "frame",
  "meta": {
    "cowartAiImageHolder": true
  }
}
```

Older canvases may still contain legacy `geo` rectangle holders with the same
meta flag. Support both shapes.

## Workflow

1. Read the selected shape from Cowart:

   ```bash
   curl -s http://127.0.0.1:43217/api/selection
   ```

   You can also use the Cowart MCP `get_cowart_selection` tool if it is available.

2. Check whether exactly one selected shape is an AI image holder. A holder is any selected shape with either:

   ```text
   isAiImageHolder: true
   ```

   or:

   ```text
   meta.cowartAiImageHolder: true
   ```

   If yes, use the holder workflow below. If not, do not ask the user to select a holder; use the standalone workflow below and insert the generated image onto a fresh Cowart page.

3. Choose the placement workflow.

   Holder workflow: use the selected holder's `props.w` and `props.h` as the size contract. The generated image should match the holder aspect ratio as closely as possible.

   If the user specified an exact output size/aspect ratio, or provided a
   reference image whose aspect ratio should be preserved, the selected holder
   must match that target ratio closely. If it does not, do not silently stretch
   the generated image. Prefer adjusting the holder/image display dimensions to
   the requested/reference ratio when that is safe; otherwise use a fresh
   standalone page sized to the requested/reference ratio and report that the
   selected holder ratio did not match.

   Do not create a holder just because a size or reference ratio exists. In the
   normal canvas workflow, apply the requested/reference ratio to the inserted
   image shape's displayed dimensions directly.

   If the holder `type` is `frame`, insert the generated image as a child of the frame:

   - `parentId`: holder shape id
   - `x`: `0`
   - `y`: `0`
   - `rotation`: `0`
   - `props.w`, `props.h`: same as holder

   This makes the generated image move with the frame.

   If the holder is a legacy `geo` rectangle, keep using the legacy placement contract: same `x`, `y`, `rotation`, `parentId`, `props.w`, and `props.h` as the holder.

   Standalone workflow: when no AI holder is selected, generate the image anyway and insert it as a normal image shape on a fresh page by default. This is the normal workflow. Use a fresh page for ordinary new image requests so previous outputs do not clutter the new task. Use the current page only when the user explicitly asks to add to the current canvas or when the task is an edit/comparison workflow. Use the generated bitmap's aspect ratio, the user-requested size/aspect ratio, or a reference image ratio. Never stretch to an unrelated ratio.

4. Generate the bitmap with the user's `image2-ai` skill unless the user explicitly requests another image path or model. `image2-ai` uses the private Image2 relay and configured `gpt-image-2` model. If the requested asset needs visible copy, labels, poster text, ad text, UI text, or typography, include that text directly in the Image2 prompt and let the image model produce the final bitmap. Do not default to generating a text-free background and then adding text locally unless the user explicitly asks for local typography, deterministic text overlay, SVG/vector output, or another non-Image2 layout step.

   Resolve the actual local output image carefully before inserting it into Cowart. Do not assume the built-in image generation flow always writes a fresh file under `$CODEX_HOME/generated_images`.

   Preferred resolution order:

   - Use the exact local image path returned by the current image generation tool call when one is available.
   - If no new file path is returned, inspect the current Codex session JSONL for the current request and extract the PNG/base64 payload from the latest `image_generation_call.result`, then write it to a timestamped output filename.
   - Use `$CODEX_HOME/generated_images` only when you can prove the file was created by the current request, for example by matching its timestamp after this generation step. Never pick an older image merely because it is the newest file in a stale generated_images directory.

   Before inserting the resolved file into Cowart, visually inspect the local bitmap and confirm it is the newly generated image for this request, not a stale generated asset.

   For project-bound output, copy the resolved generated image into the selected page's asset folder:

   ```text
   canvas/pages/<page-id-without-page-prefix>/assets/
   ```

5. Insert the generated image as a new tldraw image shape.

   Prefer the Image2 skill's reusable handoff script when available:

   ```bash
   python <image2-ai-skill>/scripts/cowart_handoff.py \
     --image <generated.png> \
     --workflow generate \
     --page-policy auto \
     --page-name "<short task name>" \
     --target-size <WIDTHxHEIGHT-or-ratio>
   ```

   Omit `--target-size` only when no explicit size/aspect ratio/reference ratio
   applies. If a selected AI holder exists, the script fills that holder; if not,
   it creates a clean page, inserts at the origin, and writes Cowart view-state
   so the image is visible when the browser opens.

   For the holder workflow, place it exactly over the holder:

   - `type`: `image`
   - `parentId`: holder id for frame holders, same as holder parent for legacy geo holders
   - `x`, `y`, `rotation`: `0`, `0`, `0` for frame holders, same as holder for legacy geo holders
   - `props.w`, `props.h`: same as holder
   - `props.assetId`: the new image asset id
   - `meta.cowartGeneratedForAiImageHolder`: holder shape id

   For the standalone workflow, insert it into the fresh/current page as a normal image:

   - `type`: `image`
   - `parentId`: current page id, unless placing beside a selected non-holder shape requires the same parent
   - `x`, `y`: `0`, `0` on a fresh page, or a clear visible area on the current page when explicitly using the current page
   - `rotation`: `0`
   - `props.w`, `props.h`: display size matching the generated bitmap aspect ratio
   - `props.assetId`: the new image asset id
   - `meta.cowartGeneratedStandalone`: `true`

6. Do not delete the holder unless the user explicitly asks for replacement. Keeping the holder lets Codex identify the intended slot again later. In the standalone workflow, do not create a holder first unless the user explicitly asks for one.

7. Save through Cowart's API or edit the page snapshot carefully:

   ```bash
   curl -s http://127.0.0.1:43217/api/canvas
   ```

   Prefer page-local asset URLs in the image asset:

   ```text
   /page-assets/<page-id-without-page-prefix>/<filename>
   ```

8. Open or focus the in-app browser on the running Cowart URL after insertion. Refresh or let the browser hot-reload, then confirm the inserted shape id, final dimensions, saved asset path, page id, and that the view-state/camera focuses the result. Include the holder id only when the holder workflow was used.

## Notes

- If the holder is a legacy rotated `geo` rectangle, preserve the same `rotation` on the image. For `frame` holders, the frame owns placement and the child image should stay unrotated inside it.
- If there is already a generated image for the same holder and the user says "替换", remove or update that generated image shape instead of piling another copy on top.
- Do not refuse generation solely because no `AI 图片` holder is selected. Generate the bitmap and insert it onto a fresh visible Cowart page.
- Do not ask for or create an AI holder unless the user explicitly wants one or has already selected one. The user's normal loop is: generate image into the canvas, annotate it, then use the annotation screenshot for AI edits.
- Never overwrite an existing asset file without an explicit replace request; use a timestamped filename.
- Avoid one-off inline Node/PowerShell state editing. Use `cowart_handoff.py` or the Cowart MCP tool first. If inline Node is unavoidable, use `node --input-type=module` with `import` statements; do not combine `require()` and top-level `await`.
