# Image2 AI Configuration

Store real credentials outside the skill.

## Private Local Config

Preferred location:

```text
%USERPROFILE%\.codex\private\image2-ai.env
```

Format:

```text
IMAGE2_API_KEY=your_private_key
IMAGE2_API_BASE=https://your-relay.example.com/v1
IMAGE2_API_MODEL=gpt-image-2
```

This file is preferred over general environment variables so Image2 does not
accidentally reuse a base URL from Photoshop or another image workflow.

## Overrides and Fallbacks

For a single run, use one of these overrides:

```text
python scripts/image2_ai.py generate --api-base https://other-relay.example.com/v1 --prompt "..."
IMAGE2_API_BASE_OVERRIDE=https://other-relay.example.com/v1
```

If no private config value is present, the script falls back to environment
variables: `IMAGE2_API_KEY`, `IMAGE2_API_BASE` or `IMAGE2_API_BASE_URL`, and
`IMAGE2_API_MODEL`.

Run `python scripts/image2_ai.py --self-test` to see the normalized base URL,
the selected model, and the base source. The API key is never printed.

Do not put this file in a project repository. Do not paste real values into
`SKILL.md`, `agents/openai.yaml`, examples, or final answers.

## Endpoint Assumption

The bundled script assumes an OpenAI-compatible image relay:

- generation: `POST /images/generations`
- editing: `POST /images/edits`

If the relay uses different paths or payload fields, patch
`scripts/image2_ai.py` only; keep the skill instructions and credentials rules
unchanged.
