#!/usr/bin/env python3
"""Check rembg packages and local model files for Image2 retouching workflows."""

from __future__ import annotations

import argparse
import importlib.util
import os
from pathlib import Path


MODELS = [
    {
        "name": "u2net",
        "file": "u2net.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2net.onnx",
        "use": "stable general background removal",
    },
    {
        "name": "u2netp",
        "file": "u2netp.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2netp.onnx",
        "use": "fast lightweight previews",
    },
    {
        "name": "u2net_human_seg",
        "file": "u2net_human_seg.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2net_human_seg.onnx",
        "use": "default person-preserving edits",
    },
    {
        "name": "u2net_cloth_seg",
        "file": "u2net_cloth_seg.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2net_cloth_seg.onnx",
        "use": "clothing masks",
    },
    {
        "name": "silueta",
        "file": "silueta.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/silueta.onnx",
        "use": "small general masks",
    },
    {
        "name": "isnet-general-use",
        "file": "isnet-general-use.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/isnet-general-use.onnx",
        "use": "higher-quality general masks",
    },
    {
        "name": "isnet-anime",
        "file": "isnet-anime.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/isnet-anime.onnx",
        "use": "anime and illustration masks",
    },
    {
        "name": "bria-rmbg",
        "file": "bria-rmbg.onnx",
        "source_file": "bria-rmbg-2.0.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/bria-rmbg-2.0.onnx",
        "use": "professional high-quality background removal",
    },
    {
        "name": "birefnet-general",
        "file": "birefnet-general.onnx",
        "source_file": "BiRefNet-general-epoch_244.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet-general-epoch_244.onnx",
        "use": "professional general segmentation",
    },
    {
        "name": "birefnet-general-lite",
        "file": "birefnet-general-lite.onnx",
        "source_file": "BiRefNet-general-bb_swin_v1_tiny-epoch_232.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet-general-bb_swin_v1_tiny-epoch_232.onnx",
        "use": "lighter BiRefNet fallback",
    },
    {
        "name": "birefnet-portrait",
        "file": "birefnet-portrait.onnx",
        "source_file": "BiRefNet-portrait-epoch_150.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet-portrait-epoch_150.onnx",
        "use": "portrait, hair, and person edges",
    },
    {
        "name": "birefnet-dis",
        "file": "birefnet-dis.onnx",
        "source_file": "BiRefNet-DIS-epoch_590.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet-DIS-epoch_590.onnx",
        "use": "dichotomous image segmentation",
    },
    {
        "name": "birefnet-hrsod",
        "file": "birefnet-hrsod.onnx",
        "source_file": "BiRefNet-HRSOD_DHU-epoch_115.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet-HRSOD_DHU-epoch_115.onnx",
        "use": "high-resolution salient object masks",
    },
    {
        "name": "birefnet-cod",
        "file": "birefnet-cod.onnx",
        "source_file": "BiRefNet-COD-epoch_125.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet-COD-epoch_125.onnx",
        "use": "camouflaged object masks",
    },
    {
        "name": "birefnet-massive",
        "file": "birefnet-massive.onnx",
        "source_file": "BiRefNet-massive-TR_DIS5K_TR_TEs-epoch_420.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/BiRefNet-massive-TR_DIS5K_TR_TEs-epoch_420.onnx",
        "use": "large professional general model",
    },
    {
        "name": "sam",
        "file": "sam_vit_b_01ec64.encoder.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/sam_vit_b_01ec64.encoder.onnx",
        "use": "SAM interactive segmentation encoder",
    },
    {
        "name": "sam",
        "file": "sam_vit_b_01ec64.decoder.onnx",
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/sam_vit_b_01ec64.decoder.onnx",
        "use": "SAM interactive segmentation decoder",
    },
]


def default_model_dir() -> Path:
    root = os.environ.get("U2NET_HOME")
    if root:
        return Path(root).expanduser()
    return Path.home() / ".u2net"


def package_present(module: str) -> bool:
    return importlib.util.find_spec(module) is not None


def main() -> int:
    parser = argparse.ArgumentParser(description="Check Image2/rembg model setup.")
    parser.add_argument(
        "--model-dir",
        default=str(default_model_dir()),
        help="Directory containing rembg ONNX models. Default: %%USERPROFILE%%\\.u2net or U2NET_HOME.",
    )
    parser.add_argument(
        "--required-only",
        action="store_true",
        help="Only require the default Image2 person-preserving model.",
    )
    args = parser.parse_args()

    model_dir = Path(args.model_dir).expanduser()
    checks = [m for m in MODELS if not args.required_only or m["file"] == "u2net_human_seg.onnx"]
    missing_packages = [pkg for pkg in ("rembg", "onnxruntime") if not package_present(pkg)]
    missing_models = [m for m in checks if not (model_dir / m["file"]).is_file()]

    print(f"Model directory: {model_dir}")
    print()

    if missing_packages:
        print("Missing Python packages:")
        for package in missing_packages:
            print(f"  - {package}")
        print("Install with:")
        print("  python -m pip install rembg onnxruntime")
        print()

    if missing_models:
        print("Missing rembg model files:")
        for model in missing_models:
            source = model.get("source_file", model["file"])
            print(f"  - save as: {model['file']}")
            if source != model["file"]:
                print(f"    downloaded file may be named: {source}")
            print(f"    model: {model['name']} ({model['use']})")
            print(f"    url: {model['url']}")
        print()

    if not missing_packages and not missing_models:
        print("All requested Image2/rembg packages and model files are present.")
        return 0

    print("After downloading, place the files in the model directory above.")
    print("Use the exact 'save as' names shown here so rembg can find them.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
