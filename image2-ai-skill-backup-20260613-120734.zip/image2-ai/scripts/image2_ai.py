#!/usr/bin/env python3
"""Call a private Image2/OpenAI-compatible relay for generation and edits."""

from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path


DEFAULT_MODEL = "gpt-image-2"
PRIVATE_ENV = Path.home() / ".codex" / "private" / "image2-ai.env"
CONFIG_KEYS = {
    "IMAGE2_API_KEY",
    "IMAGE2_API_BASE",
    "IMAGE2_API_BASE_URL",
    "IMAGE2_API_MODEL",
}


def read_private_env() -> dict[str, str]:
    values: dict[str, str] = {}
    if not PRIVATE_ENV.exists():
        return values
    for raw_line in PRIVATE_ENV.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key in CONFIG_KEYS and value:
            values[key] = value
    return values


def first_value(*values: str | None) -> str:
    for value in values:
        if value and value.strip():
            return value.strip()
    return ""


def config(args: argparse.Namespace | None = None) -> tuple[str, str, str, str]:
    private = read_private_env()
    api_base_arg = getattr(args, "api_base", None) if args else None
    model_arg = getattr(args, "model", None) if args else None

    api_key = first_value(
        private.get("IMAGE2_API_KEY"),
        os.environ.get("IMAGE2_API_KEY"),
    )
    base = (
        first_value(api_base_arg)
        or first_value(os.environ.get("IMAGE2_API_BASE_OVERRIDE"))
        or first_value(private.get("IMAGE2_API_BASE"), private.get("IMAGE2_API_BASE_URL"))
        or first_value(os.environ.get("IMAGE2_API_BASE"), os.environ.get("IMAGE2_API_BASE_URL"))
    )
    model = (
        first_value(model_arg)
        or first_value(private.get("IMAGE2_API_MODEL"))
        or first_value(os.environ.get("IMAGE2_API_MODEL"))
        or DEFAULT_MODEL
    )
    missing = []
    if not api_key:
        missing.append("IMAGE2_API_KEY")
    if not base:
        missing.append("IMAGE2_API_BASE or IMAGE2_API_BASE_URL")
    if missing:
        raise SystemExit(
            "Missing Image2 configuration: "
            + ", ".join(missing)
            + f". Set environment variables or create {PRIVATE_ENV}."
        )
    source = "command"
    if not first_value(api_base_arg):
        if first_value(os.environ.get("IMAGE2_API_BASE_OVERRIDE")):
            source = "IMAGE2_API_BASE_OVERRIDE"
        elif first_value(private.get("IMAGE2_API_BASE"), private.get("IMAGE2_API_BASE_URL")):
            source = str(PRIVATE_ENV)
        else:
            source = "environment"
    return api_key, normalize_base(base), model, source


def normalize_base(base: str) -> str:
    base = base.rstrip("/")
    if not base.endswith("/v1"):
        base = base + "/v1"
    return base


def request_json(url: str, api_key: str, payload: dict, timeout: int) -> dict:
    body = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except TimeoutError as exc:
        raise SystemExit(f"Image2 request timed out after {timeout} seconds.") from exc
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"Image2 HTTP {exc.code}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise SystemExit(f"Image2 request failed: {exc}") from exc


def request_multipart(
    url: str,
    api_key: str,
    fields: dict,
    files: list[tuple[str, Path]],
    timeout: int,
) -> dict:
    boundary = f"----image2ai{int(time.time() * 1000)}"
    chunks: list[bytes] = []
    for key, value in fields.items():
        chunks.extend(
            [
                f"--{boundary}\r\n".encode(),
                f'Content-Disposition: form-data; name="{key}"\r\n\r\n'.encode(),
                str(value).encode("utf-8"),
                b"\r\n",
            ]
        )
    for key, path in files:
        mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        chunks.extend(
            [
                f"--{boundary}\r\n".encode(),
                (
                    f'Content-Disposition: form-data; name="{key}"; '
                    f'filename="{path.name}"\r\n'
                ).encode(),
                f"Content-Type: {mime}\r\n\r\n".encode(),
                path.read_bytes(),
                b"\r\n",
            ]
        )
    chunks.append(f"--{boundary}--\r\n".encode())
    body = b"".join(chunks)
    request = urllib.request.Request(
        url,
        data=body,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except TimeoutError as exc:
        raise SystemExit(f"Image2 request timed out after {timeout} seconds.") from exc
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"Image2 HTTP {exc.code}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise SystemExit(f"Image2 request failed: {exc}") from exc


def ensure_out_dir(path: str | None) -> Path:
    out_dir = Path(path) if path else Path.cwd() / "outputs"
    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir


def save_images(response: dict, out_dir: Path, prefix: str, timeout: int) -> list[Path]:
    data = response.get("data")
    if not isinstance(data, list) or not data:
        raise SystemExit("Image2 response did not contain data[].")
    saved: list[Path] = []
    for index, item in enumerate(data, start=1):
        if not isinstance(item, dict):
            continue
        suffix = f"{int(time.time())}-{index}"
        if item.get("b64_json"):
            image_bytes = base64.b64decode(item["b64_json"])
            path = out_dir / f"{prefix}-{suffix}.png"
            path.write_bytes(image_bytes)
            saved.append(path)
        elif item.get("url"):
            url = item["url"]
            try:
                with urllib.request.urlopen(url, timeout=timeout) as response_url:
                    image_bytes = response_url.read()
            except TimeoutError as exc:
                raise SystemExit(f"Image2 image download timed out after {timeout} seconds.") from exc
            ext = Path(url.split("?", 1)[0]).suffix or ".png"
            path = out_dir / f"{prefix}-{suffix}{ext}"
            path.write_bytes(image_bytes)
            saved.append(path)
    if not saved:
        raise SystemExit("Image2 response contained no b64_json or url images.")
    return saved


def generate(args: argparse.Namespace) -> list[Path]:
    api_key, base, model, _source = config(args)
    payload = {
        "model": model,
        "prompt": args.prompt,
        "quality": args.quality,
        "n": args.n,
    }
    if args.response_format:
        payload["response_format"] = args.response_format
    response = request_json(f"{base}/images/generations", api_key, payload, args.timeout)
    return save_images(response, ensure_out_dir(args.out_dir), "image2-generate", args.timeout)


def edit(args: argparse.Namespace) -> list[Path]:
    api_key, base, model, _source = config(args)
    image_path = Path(args.image)
    if not image_path.exists():
        raise SystemExit(f"Input image not found: {image_path}")
    fields = {
        "model": model,
        "prompt": args.prompt,
        "quality": args.quality,
        "n": args.n,
    }
    if args.response_format:
        fields["response_format"] = args.response_format
    files = [("image", image_path)]
    if args.mask:
        mask_path = Path(args.mask)
        if not mask_path.exists():
            raise SystemExit(f"Mask image not found: {mask_path}")
        files.append(("mask", mask_path))
    response = request_multipart(f"{base}/images/edits", api_key, fields, files, args.timeout)
    return save_images(response, ensure_out_dir(args.out_dir), "image2-edit", args.timeout)


def self_test() -> None:
    api_key, base, model, source = config()
    print(
        json.dumps(
            {
                "base_configured": True,
                "base": base,
                "base_source": source,
                "model": model,
                "api_key_configured": bool(api_key),
            },
            indent=2,
        )
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true", help="Check configuration only.")
    subparsers = parser.add_subparsers(dest="command")

    gen = subparsers.add_parser("generate")
    gen.add_argument("--prompt", required=True)
    gen.add_argument("--out-dir")
    gen.add_argument("--model")
    gen.add_argument("--api-base")
    gen.add_argument("--quality", default="high")
    gen.add_argument("--n", type=int, default=1)
    gen.add_argument("--response-format", default="b64_json")
    gen.add_argument("--timeout", type=int, default=600)

    edt = subparsers.add_parser("edit")
    edt.add_argument("--prompt", required=True)
    edt.add_argument("--image", required=True)
    edt.add_argument("--mask")
    edt.add_argument("--out-dir")
    edt.add_argument("--model")
    edt.add_argument("--api-base")
    edt.add_argument("--quality", default="high")
    edt.add_argument("--n", type=int, default=1)
    edt.add_argument("--response-format", default="b64_json")
    edt.add_argument("--timeout", type=int, default=600)

    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    if args.command == "generate":
        paths = generate(args)
    elif args.command == "edit":
        paths = edit(args)
    else:
        parser.print_help()
        sys.exit(2)
    print(json.dumps({"saved": [str(path) for path in paths]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

