#!/usr/bin/env python3
"""Composite original person pixels over an edited background.

This is for Image2 edits where the user wants the person unchanged while the
background receives the AI treatment. It uses rembg only for the alpha mask; the
visible person pixels come from the original image to avoid rembg fringe colors.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np
from PIL import Image
from rembg import new_session, remove


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Preserve the original person while using an edited background."
    )
    parser.add_argument("--original", required=True, help="Original photo path.")
    parser.add_argument("--edited", required=True, help="Image2 edited background path.")
    parser.add_argument("--output", required=True, help="Final composited output path.")
    parser.add_argument(
        "--mask-output",
        help="Optional path to write the cleaned alpha mask for inspection.",
    )
    parser.add_argument(
        "--model",
        default="u2net_human_seg",
        help="rembg model name. Default: u2net_human_seg.",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.12,
        help="Drop weak alpha below this value to remove fringe. Default: 0.12.",
    )
    parser.add_argument(
        "--gain",
        type=float,
        default=0.62,
        help="Alpha normalization width after threshold. Lower is harder. Default: 0.62.",
    )
    parser.add_argument(
        "--solid",
        type=float,
        default=0.82,
        help="Alpha above this becomes fully opaque. Default: 0.82.",
    )
    parser.add_argument(
        "--erode",
        type=int,
        default=1,
        help="Mask erosion iterations to remove background edge spill. Default: 1.",
    )
    parser.add_argument(
        "--feather",
        type=float,
        default=0.45,
        help="Small Gaussian blur sigma for natural edges. Default: 0.45.",
    )
    return parser.parse_args()


def load_person_mask(original: Image.Image, model: str) -> Image.Image:
    session = new_session(model, providers=["CPUExecutionProvider"])
    cutout = remove(
        original.convert("RGBA"),
        session=session,
        alpha_matting=True,
        alpha_matting_foreground_threshold=240,
        alpha_matting_background_threshold=10,
        alpha_matting_erode_size=6,
    )
    return cutout.getchannel("A")


def clean_alpha(
    mask: Image.Image,
    *,
    threshold: float,
    gain: float,
    solid: float,
    erode: int,
    feather: float,
) -> np.ndarray:
    alpha = np.asarray(mask.convert("L")).astype(np.float32) / 255.0
    alpha = np.clip((alpha - threshold) / gain, 0.0, 1.0)
    alpha[alpha >= solid] = 1.0
    alpha[alpha < 0.045] = 0.0

    alpha_u8 = (alpha * 255).astype(np.uint8)
    if erode > 0:
        alpha_u8 = cv2.erode(alpha_u8, np.ones((3, 3), np.uint8), iterations=erode)
    if feather > 0:
        alpha_u8 = cv2.GaussianBlur(alpha_u8, (3, 3), feather)
    return alpha_u8.astype(np.float32) / 255.0


def composite(original_path: Path, edited_path: Path, output_path: Path, args: argparse.Namespace) -> None:
    original = Image.open(original_path).convert("RGB")
    edited = Image.open(edited_path).convert("RGB").resize(original.size, Image.Resampling.LANCZOS)

    raw_mask = load_person_mask(original, args.model).resize(original.size, Image.Resampling.LANCZOS)
    alpha = clean_alpha(
        raw_mask,
        threshold=args.threshold,
        gain=args.gain,
        solid=args.solid,
        erode=args.erode,
        feather=args.feather,
    )

    original_np = np.asarray(original).astype(np.float32)
    edited_np = np.asarray(edited).astype(np.float32)
    final = (original_np * alpha[..., None] + edited_np * (1.0 - alpha[..., None])).clip(0, 255)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(final.astype(np.uint8)).save(output_path)

    if args.mask_output:
        mask_path = Path(args.mask_output)
        mask_path.parent.mkdir(parents=True, exist_ok=True)
        Image.fromarray((alpha * 255).astype(np.uint8)).save(mask_path)


def main() -> None:
    args = parse_args()
    composite(Path(args.original), Path(args.edited), Path(args.output), args)


if __name__ == "__main__":
    main()
