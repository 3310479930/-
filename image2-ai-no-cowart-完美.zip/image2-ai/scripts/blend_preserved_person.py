#!/usr/bin/env python3
"""Composite original person pixels with natural environment matching.

Use this after an Image2 background edit when identity and pose must stay
unchanged, but the preserved person should visually belong to the edited scene.
The script never uses generative editing on the person; it applies deterministic
color, contrast, and edge blending to the original person pixels.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np
from PIL import Image
from rembg import new_session, remove


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Preserve and naturally blend a person into an edited scene.")
    parser.add_argument("--original", required=True, help="Original photo path.")
    parser.add_argument("--edited", required=True, help="Image2 edited scene path.")
    parser.add_argument("--output", required=True, help="Final blended output path.")
    parser.add_argument("--mask-output", help="Optional cleaned mask output path.")
    parser.add_argument("--model", default="u2net_human_seg", help="rembg model name.")
    parser.add_argument("--threshold", type=float, default=0.12, help="Drop weak alpha below this value.")
    parser.add_argument("--gain", type=float, default=0.62, help="Alpha normalization width after threshold.")
    parser.add_argument("--solid", type=float, default=0.82, help="Alpha above this becomes fully opaque.")
    parser.add_argument("--erode", type=int, default=1, help="Mask erosion iterations.")
    parser.add_argument("--feather", type=float, default=0.45, help="Small Gaussian blur sigma for edges.")
    parser.add_argument(
        "--match-strength",
        type=float,
        default=0.86,
        help="Color/contrast match strength, 0-1. Natural environment default: 0.86.",
    )
    parser.add_argument(
        "--edge-strength",
        type=float,
        default=0.30,
        help="How much edited-scene color is mixed into the person edge, 0-1.",
    )
    parser.add_argument(
        "--grain-strength",
        type=float,
        default=0.022,
        help="Subtle luminance grain added to person so texture matches cinematic backgrounds.",
    )
    parser.add_argument(
        "--relight-strength",
        type=float,
        default=0.84,
        help="Match subject luminance to the edited environment, 0-1. Raises/lower exposure without AI redraw.",
    )
    parser.add_argument(
        "--highlight-rolloff",
        type=float,
        default=0.76,
        help="Compress bright clothing/skin highlights so they do not float above dark cinematic scenes.",
    )
    parser.add_argument(
        "--local-light-strength",
        type=float,
        default=0.52,
        help="Apply the edited background's broad local light map to the person, 0-1.",
    )
    parser.add_argument(
        "--ambient-shadow-strength",
        type=float,
        default=0.24,
        help="Subtle scene-colored shadow near subject edges to reduce pasted cutout feel, 0-1.",
    )
    parser.add_argument(
        "--detail-strength",
        type=float,
        default=0.72,
        help="Restore original-person high-frequency detail after color/light matching, 0-1.",
    )
    parser.add_argument(
        "--sharpen-strength",
        type=float,
        default=0.24,
        help="Small unsharp mask on preserved person only, 0-1.",
    )
    return parser.parse_args()


def load_person_mask(original: Image.Image, model: str) -> Image.Image:
    session = new_session(model, providers=["CPUExecutionProvider"])
    cutout = remove(
        original.convert("RGBA"),
        session=session,
        alpha_matting=True,
        alpha_matting_foreground_threshold=240,
        alpha_matting_background_threshold=10,
        alpha_matting_erode_size=6,
    )
    return cutout.getchannel("A")


def clean_alpha(mask: Image.Image, threshold: float, gain: float, solid: float, erode: int, feather: float) -> np.ndarray:
    alpha = np.asarray(mask.convert("L")).astype(np.float32) / 255.0
    alpha = np.clip((alpha - threshold) / gain, 0.0, 1.0)
    alpha[alpha >= solid] = 1.0
    alpha[alpha < 0.045] = 0.0

    alpha_u8 = (alpha * 255).astype(np.uint8)
    if erode > 0:
        alpha_u8 = cv2.erode(alpha_u8, np.ones((3, 3), np.uint8), iterations=erode)
    if feather > 0:
        alpha_u8 = cv2.GaussianBlur(alpha_u8, (3, 3), feather)
    return alpha_u8.astype(np.float32) / 255.0


def masked_stats(lab: np.ndarray, mask: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    pixels = lab[mask]
    if pixels.size == 0:
        pixels = lab.reshape(-1, 3)
    mean = pixels.mean(axis=0)
    std = pixels.std(axis=0)
    return mean, np.maximum(std, 1.0)


def make_ring(alpha_u8: np.ndarray) -> np.ndarray:
    subject = alpha_u8 > 24
    kernel = np.ones((21, 21), np.uint8)
    outer = cv2.dilate(subject.astype(np.uint8), kernel, iterations=2).astype(bool)
    inner = cv2.dilate(subject.astype(np.uint8), np.ones((5, 5), np.uint8), iterations=1).astype(bool)
    ring = outer & ~inner
    if ring.sum() < 500:
        ring = ~subject
    return ring


def match_person_to_environment(
    original_rgb: np.ndarray,
    edited_rgb: np.ndarray,
    alpha: np.ndarray,
    strength: float,
    relight_strength: float,
    highlight_rolloff: float,
) -> np.ndarray:
    strength = float(np.clip(strength, 0.0, 1.0))
    relight_strength = float(np.clip(relight_strength, 0.0, 1.0))
    highlight_rolloff = float(np.clip(highlight_rolloff, 0.0, 1.0))
    original_lab = cv2.cvtColor(original_rgb.astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
    edited_lab = cv2.cvtColor(edited_rgb.astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)

    alpha_u8 = (alpha * 255).astype(np.uint8)
    person = alpha > 0.35
    core = alpha > 0.82
    ring = make_ring(alpha_u8)

    src_bg_mean, src_bg_std = masked_stats(original_lab, ring)
    dst_bg_mean, dst_bg_std = masked_stats(edited_lab, ring)
    person_mask = core if core.sum() > 200 else person
    person_mean, _ = masked_stats(original_lab, person_mask)

    # Apply the environment shift, not a full recolor. This keeps identity and
    # clothing recognizable while picking up the edited scene's temperature.
    delta = dst_bg_mean - src_bg_mean
    channel_strength = np.array([0.45, 0.72, 0.72], dtype=np.float32) * strength
    contrast_ratio = np.clip(dst_bg_std / src_bg_std, 0.72, 1.28)
    contrast_strength = np.array([0.34, 0.18, 0.18], dtype=np.float32) * strength

    matched = original_lab.copy()
    person_lab = matched[person]
    ratio = 1.0 + (contrast_ratio - 1.0) * contrast_strength
    person_lab = (person_lab - person_mean) * ratio + person_mean + delta * channel_strength

    # Preserve subject separation, but reduce the original "studio cutout"
    # brightness when the AI background becomes darker and more cinematic.
    original_scene_gap = person_mean[0] - src_bg_mean[0]
    desired_gap = original_scene_gap * (0.48 + 0.30 * (1.0 - strength))
    desired_person_l = dst_bg_mean[0] + desired_gap
    luma_shift = np.clip(desired_person_l - person_mean[0], -62.0, 28.0)
    person_lab[:, 0] += luma_shift * relight_strength

    # Roll off strong whites after exposure matching. This keeps white clothes
    # white, but avoids the flat pasted-on white block look in dark scenes.
    bright = person_lab[:, 0] > 178.0
    if np.any(bright) and highlight_rolloff > 0:
        pivot = 168.0
        person_lab[bright, 0] = pivot + (person_lab[bright, 0] - pivot) * (1.0 - 0.42 * highlight_rolloff)

    matched[person] = np.clip(person_lab, 0, 255)
    return cv2.cvtColor(matched.astype(np.uint8), cv2.COLOR_LAB2RGB).astype(np.float32)


def edge_integrate(person_rgb: np.ndarray, edited_rgb: np.ndarray, alpha: np.ndarray, strength: float) -> np.ndarray:
    strength = float(np.clip(strength, 0.0, 1.0))
    alpha_u8 = (alpha * 255).astype(np.uint8)
    dilated = cv2.dilate(alpha_u8, np.ones((9, 9), np.uint8), iterations=1).astype(np.float32) / 255.0
    eroded = cv2.erode(alpha_u8, np.ones((5, 5), np.uint8), iterations=1).astype(np.float32) / 255.0
    edge = np.clip(dilated - eroded, 0.0, 1.0)
    edge = cv2.GaussianBlur(edge, (0, 0), 2.0)[..., None]

    ambient = cv2.GaussianBlur(edited_rgb.astype(np.float32), (0, 0), 5.0)
    edge_mix = edge * strength
    return person_rgb * (1.0 - edge_mix) + ambient * edge_mix


def apply_local_scene_light(person_rgb: np.ndarray, edited_rgb: np.ndarray, alpha: np.ndarray, strength: float) -> np.ndarray:
    strength = float(np.clip(strength, 0.0, 1.0))
    if strength <= 0:
        return person_rgb

    edited_gray = cv2.cvtColor(edited_rgb.astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32) / 255.0
    local_light = cv2.GaussianBlur(edited_gray, (0, 0), 42.0)
    subject = alpha > 0.35
    if subject.sum() < 200:
        return person_rgb

    subject_mean = float(local_light[subject].mean())
    local_ratio = np.clip(local_light / max(subject_mean, 0.04), 0.72, 1.22)
    local_ratio = 1.0 + (local_ratio - 1.0) * strength

    # Add a gentle under-umbrella/top falloff so bright preserved portraits do
    # not keep flat studio light inside a dark, moody scene.
    ys = np.linspace(0.0, 1.0, alpha.shape[0], dtype=np.float32)[:, None]
    vertical = 0.90 + 0.16 * ys
    vertical = 1.0 + (vertical - 1.0) * (0.45 * strength)

    return np.clip(person_rgb * local_ratio[..., None] * vertical[..., None], 0, 255)


def ambient_edge_shadow(edited_rgb: np.ndarray, alpha: np.ndarray, strength: float) -> np.ndarray:
    strength = float(np.clip(strength, 0.0, 1.0))
    if strength <= 0:
        return edited_rgb
    alpha_u8 = (alpha * 255).astype(np.uint8)
    outer = cv2.dilate(alpha_u8, np.ones((19, 19), np.uint8), iterations=1).astype(np.float32) / 255.0
    inner = cv2.dilate(alpha_u8, np.ones((5, 5), np.uint8), iterations=1).astype(np.float32) / 255.0
    ring = np.clip(outer - inner, 0.0, 1.0)
    ring = cv2.GaussianBlur(ring, (0, 0), 5.0)[..., None]

    ambient = cv2.GaussianBlur(edited_rgb.astype(np.float32), (0, 0), 18.0)
    shadow_tint = ambient * 0.72
    return edited_rgb * (1.0 - ring * strength) + shadow_tint * (ring * strength)


def add_person_grain(person_rgb: np.ndarray, alpha: np.ndarray, strength: float) -> np.ndarray:
    if strength <= 0:
        return person_rgb
    rng = np.random.default_rng(12345)
    noise = rng.normal(0.0, 255.0 * strength, alpha.shape).astype(np.float32)
    noise = cv2.GaussianBlur(noise, (0, 0), 0.55)
    return np.clip(person_rgb + noise[..., None] * np.clip(alpha[..., None], 0.0, 1.0), 0, 255)


def restore_original_detail(
    matched_rgb: np.ndarray,
    original_rgb: np.ndarray,
    alpha: np.ndarray,
    detail_strength: float,
    sharpen_strength: float,
) -> np.ndarray:
    detail_strength = float(np.clip(detail_strength, 0.0, 1.0))
    sharpen_strength = float(np.clip(sharpen_strength, 0.0, 1.0))
    if detail_strength <= 0 and sharpen_strength <= 0:
        return matched_rgb

    matched_lab = cv2.cvtColor(matched_rgb.astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
    original_lab = cv2.cvtColor(original_rgb.astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)

    original_l = original_lab[:, :, 0]
    original_base = cv2.GaussianBlur(original_l, (0, 0), 1.15)
    high_freq = original_l - original_base

    alpha_detail = np.clip(alpha, 0.0, 1.0)
    edge_guard = cv2.erode((alpha_detail * 255).astype(np.uint8), np.ones((3, 3), np.uint8), iterations=1)
    edge_guard = edge_guard.astype(np.float32) / 255.0

    matched_lab[:, :, 0] += high_freq * detail_strength * edge_guard

    if sharpen_strength > 0:
        l_blur = cv2.GaussianBlur(matched_lab[:, :, 0], (0, 0), 0.85)
        matched_lab[:, :, 0] += (matched_lab[:, :, 0] - l_blur) * sharpen_strength * edge_guard

    matched_lab[:, :, 0] = np.clip(matched_lab[:, :, 0], 0, 255)
    return cv2.cvtColor(matched_lab.astype(np.uint8), cv2.COLOR_LAB2RGB).astype(np.float32)


def composite(args: argparse.Namespace) -> None:
    original = Image.open(args.original).convert("RGB")
    edited = Image.open(args.edited).convert("RGB").resize(original.size, Image.Resampling.LANCZOS)

    raw_mask = load_person_mask(original, args.model).resize(original.size, Image.Resampling.LANCZOS)
    alpha = clean_alpha(raw_mask, args.threshold, args.gain, args.solid, args.erode, args.feather)

    original_np = np.asarray(original).astype(np.float32)
    edited_np = np.asarray(edited).astype(np.float32)

    matched = match_person_to_environment(
        original_np,
        edited_np,
        alpha,
        args.match_strength,
        args.relight_strength,
        args.highlight_rolloff,
    )
    matched = apply_local_scene_light(matched, edited_np, alpha, args.local_light_strength)
    matched = edge_integrate(matched, edited_np, alpha, args.edge_strength)
    matched = restore_original_detail(
        matched,
        original_np,
        alpha,
        args.detail_strength,
        args.sharpen_strength,
    )
    matched = add_person_grain(matched, alpha, args.grain_strength)

    integrated_background = ambient_edge_shadow(edited_np, alpha, args.ambient_shadow_strength)
    final = (matched * alpha[..., None] + integrated_background * (1.0 - alpha[..., None])).clip(0, 255)
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(final.astype(np.uint8)).save(output_path)

    if args.mask_output:
        mask_path = Path(args.mask_output)
        mask_path.parent.mkdir(parents=True, exist_ok=True)
        Image.fromarray((alpha * 255).astype(np.uint8)).save(mask_path)


def main() -> None:
    composite(parse_args())


if __name__ == "__main__":
    main()
