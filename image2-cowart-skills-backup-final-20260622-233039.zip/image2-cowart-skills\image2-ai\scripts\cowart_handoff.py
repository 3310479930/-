#!/usr/bin/env python3
"""Place generated Image2 outputs into Cowart in a predictable, visible way."""

from __future__ import annotations

import argparse
import json
import mimetypes
import shutil
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from PIL import Image


DEFAULT_COWART_URL = "http://127.0.0.1:43217"
PAGE_ID_PREFIX = "page:"
PAGE_ASSETS_ROUTE = "/page-assets/"


def http_json(method: str, url: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    data = None
    headers = {"accept": "application/json"}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["content-type"] = "application/json"
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            body = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"{method} {url} failed: {exc.code} {detail}") from exc
    except urllib.error.URLError as exc:
        raise SystemExit(f"Could not reach Cowart at {url}: {exc.reason}") from exc
    return json.loads(body) if body else {}


def non_empty(value: str | None) -> str | None:
    if value and value.strip():
        return value.strip()
    return None


def image_size(path: Path) -> tuple[int, int]:
    with Image.open(path) as image:
        return image.size


def parse_size(value: str | None) -> tuple[float, float] | None:
    if not value:
        return None
    normalized = value.lower().replace(":", "x").replace("*", "x")
    if "x" not in normalized:
        raise SystemExit(f"Invalid size/ratio '{value}'. Expected WIDTHxHEIGHT.")
    left, right = normalized.split("x", 1)
    try:
        width = float(left)
        height = float(right)
    except ValueError as exc:
        raise SystemExit(f"Invalid size/ratio '{value}'. Expected WIDTHxHEIGHT.") from exc
    if width <= 0 or height <= 0:
        raise SystemExit(f"Invalid size/ratio '{value}'. Values must be positive.")
    return width, height


def page_dir_name(page_id: str) -> str:
    return urllib.parse.quote(page_id.replace(PAGE_ID_PREFIX, ""), safe="")


def page_asset_url(page_id: str, file_name: str) -> str:
    return f"{PAGE_ASSETS_ROUTE}{page_dir_name(page_id)}/{urllib.parse.quote(file_name)}"


def sanitize_file_name(name: str, fallback: str = "image.png") -> str:
    raw = Path(name or fallback).name or fallback
    stem = Path(raw).stem
    suffix = Path(raw).suffix or Path(fallback).suffix or ".png"
    clean = "".join(char if char.isalnum() or char in "._-" else "-" for char in stem).strip("-")
    return f"{clean or 'image'}{suffix}"


def sanitize_id_part(value: str, fallback: str = "image") -> str:
    stem = Path(value or fallback).stem
    clean = "".join(char if char.isalnum() or char in "_-" else "-" for char in stem).strip("-")
    return (clean or fallback)[:80]


def unique_file_path(directory: Path, requested_name: str) -> tuple[str, Path]:
    safe_name = sanitize_file_name(requested_name)
    stem = Path(safe_name).stem
    suffix = Path(safe_name).suffix
    candidate = safe_name
    counter = 2
    while True:
        path = directory / candidate
        if not path.exists():
            return candidate, path
        candidate = f"{stem}-v{counter}{suffix}"
        counter += 1


def unique_record_id(store: dict[str, Any], prefix: str, seed: str) -> str:
    clean = sanitize_id_part(seed)
    candidate = f"{prefix}:{clean}"
    counter = 2
    while candidate in store:
        candidate = f"{prefix}:{clean}-{counter}"
        counter += 1
    return candidate


def next_index(records: list[dict[str, Any]]) -> str:
    existing = {record.get("index") for record in records}
    counter = len(records) + 1
    while True:
        candidate = f"a{counter}"
        if candidate not in existing:
            return candidate
        counter += 1


def record_bounds(shape: dict[str, Any], store: dict[str, Any]) -> dict[str, float]:
    props = shape.get("props") or {}
    if shape.get("type") == "arrow":
        start = props.get("start") or {"x": 0, "y": 0}
        end = props.get("end") or {"x": 1, "y": 1}
        width = max(1.0, abs(float(end.get("x", 0)) - float(start.get("x", 0))))
        height = max(1.0, abs(float(end.get("y", 0)) - float(start.get("y", 0))))
    else:
        width = float(props.get("w") or 1)
        height = float(props.get("h") or 1)
    x = float(shape.get("x") or 0)
    y = float(shape.get("y") or 0)
    parent = store.get(shape.get("parentId"))
    seen = {shape.get("id")}
    while parent and parent.get("typeName") == "shape" and parent.get("id") not in seen:
        seen.add(parent.get("id"))
        x += float(parent.get("x") or 0)
        y += float(parent.get("y") or 0)
        parent = store.get(parent.get("parentId"))
    return {"x": x, "y": y, "w": width, "h": height}


def rects_overlap(a: dict[str, float], b: dict[str, float], padding: float = 0) -> bool:
    return not (
        a["x"] + a["w"] + padding <= b["x"]
        or b["x"] + b["w"] + padding <= a["x"]
        or a["y"] + a["h"] + padding <= b["y"]
        or b["y"] + b["h"] + padding <= a["y"]
    )


def union_bounds(bounds: list[dict[str, float]]) -> dict[str, float]:
    min_x = min(item["x"] for item in bounds)
    min_y = min(item["y"] for item in bounds)
    max_x = max(item["x"] + item["w"] for item in bounds)
    max_y = max(item["y"] + item["h"] for item in bounds)
    return {"x": min_x, "y": min_y, "w": max_x - min_x, "h": max_y - min_y}


def find_page_for_shape(store: dict[str, Any], shape_id: str) -> str | None:
    record = store.get(shape_id)
    seen: set[str] = set()
    while record and record.get("id") not in seen:
        seen.add(record["id"])
        if record.get("typeName") == "page":
            return record["id"]
        parent_id = record.get("parentId")
        parent = store.get(parent_id)
        if parent and parent.get("typeName") == "page":
            return parent["id"]
        record = parent
    return None


def page_shapes(store: dict[str, Any], page_id: str) -> list[dict[str, Any]]:
    by_parent: dict[str, list[dict[str, Any]]] = {}
    for record in store.values():
        if record.get("typeName") == "shape":
            by_parent.setdefault(record.get("parentId"), []).append(record)
    shapes: list[dict[str, Any]] = []
    queue = list(by_parent.get(page_id, []))
    while queue:
        shape = queue.pop(0)
        shapes.append(shape)
        queue.extend(by_parent.get(shape.get("id"), []))
    return shapes


def is_ai_holder(shape: dict[str, Any] | None) -> bool:
    if not shape:
        return False
    meta = shape.get("meta") or {}
    return bool(shape.get("isAiImageHolder") or meta.get("cowartAiImageHolder"))


def selected_shape_ids(cowart_url: str) -> list[str]:
    try:
        payload = http_json("GET", f"{cowart_url}/api/selection")
    except SystemExit:
        return []
    selected = payload.get("selection", {}).get("selectedShapes", [])
    return [shape.get("id") for shape in selected if shape.get("id")]


def infer_canvas_dir(payload: dict[str, Any], project_dir: Path | None, canvas_dir: Path | None) -> Path:
    if canvas_dir:
        return canvas_dir
    raw_path = payload.get("path")
    if raw_path:
        path = Path(raw_path)
        if path.name == "pages":
            return path.parent
        if path.name == "cowart-canvas.json":
            return path.parent
    if project_dir:
        return project_dir / "canvas"
    return Path.cwd() / "canvas"


def target_display_size(
    image_width: int,
    image_height: int,
    display_width: float | None,
    display_height: float | None,
    target_ratio: tuple[float, float] | None,
    default_width: float = 512,
) -> tuple[float, float]:
    ratio = (image_width, image_height)
    if target_ratio:
        ratio = target_ratio
    if display_width and display_height:
        return display_width, display_height
    if display_width:
        return display_width, round(display_width * ratio[1] / ratio[0], 3)
    if display_height:
        return round(display_height * ratio[0] / ratio[1], 3), display_height
    return default_width, round(default_width * ratio[1] / ratio[0], 3)


def ratio_mismatch(
    image_width: int,
    image_height: int,
    target_ratio: tuple[float, float] | None,
    tolerance: float = 0.02,
) -> float | None:
    if not target_ratio:
        return None
    image_ratio = image_width / image_height
    expected_ratio = target_ratio[0] / target_ratio[1]
    delta = abs(image_ratio - expected_ratio) / expected_ratio
    return delta if delta > tolerance else None


def create_page(store: dict[str, Any], requested_name: str | None) -> str:
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    seed = sanitize_id_part(requested_name or f"image2-{timestamp}", f"image2-{timestamp}")
    page_id = f"page:{seed}"
    counter = 2
    while page_id in store:
        page_id = f"page:{seed}-{counter}"
        counter += 1
    pages = [record for record in store.values() if record.get("typeName") == "page"]
    store[page_id] = {
        "meta": {},
        "id": page_id,
        "name": requested_name or f"Image2 {timestamp}",
        "index": next_index(pages),
        "typeName": "page",
    }
    return page_id


def choose_clear_position(
    store: dict[str, Any],
    page_id: str,
    parent_id: str,
    width: float,
    height: float,
    anchor: dict[str, Any] | None,
    placement: str,
    margin: float,
) -> tuple[float, float, dict[str, float] | None]:
    anchor_bounds = record_bounds(anchor, store) if anchor else None
    if anchor_bounds:
        x = anchor_bounds["x"] + anchor_bounds["w"] + margin
        y = anchor_bounds["y"]
        if placement == "left":
            x = anchor_bounds["x"] - width - margin
        elif placement == "below":
            x = anchor_bounds["x"]
            y = anchor_bounds["y"] + anchor_bounds["h"] + margin
    else:
        x, y = 0.0, 0.0
    obstacles = [
        record_bounds(shape, store)
        for shape in page_shapes(store, page_id)
        if shape.get("parentId") == parent_id and shape.get("id") != (anchor or {}).get("id")
    ]
    step_x = width + margin
    step_y = height + margin
    for _ in range(60):
        candidate = {"x": x, "y": y, "w": width, "h": height}
        if not any(rects_overlap(candidate, obstacle, margin / 2) for obstacle in obstacles):
            return x, y, anchor_bounds
        if placement == "below":
            y += step_y
        elif placement == "left":
            x -= step_x
        else:
            x += step_x
    return x, y, anchor_bounds


def set_view_state(
    cowart_url: str,
    page_id: str,
    focus_bounds: dict[str, float],
    viewport_width: float,
    viewport_height: float,
) -> dict[str, Any]:
    z = min((viewport_width - 120) / max(focus_bounds["w"], 1), (viewport_height - 160) / max(focus_bounds["h"], 1), 1.1)
    z = max(0.15, min(z, 1.1))
    camera = {
        "x": round(60 - focus_bounds["x"] * z, 3),
        "y": round(80 - focus_bounds["y"] * z, 3),
        "z": round(z, 6),
    }
    view_state = {
        "version": 1,
        "currentPageId": page_id,
        "camera": camera,
        "updatedAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    http_json("PUT", f"{cowart_url}/api/view-state", view_state)
    return view_state


def remove_holder_images(store: dict[str, Any], holder_id: str) -> list[str]:
    removed_shapes: list[str] = []
    removed_assets: set[str] = set()
    for shape_id, record in list(store.items()):
        if record.get("typeName") != "shape" or record.get("type") != "image":
            continue
        meta = record.get("meta") or {}
        if record.get("parentId") == holder_id or meta.get("cowartGeneratedForAiImageHolder") == holder_id:
            removed_shapes.append(shape_id)
            asset_id = record.get("props", {}).get("assetId")
            if asset_id:
                removed_assets.add(asset_id)
            del store[shape_id]
    still_used = {
        record.get("props", {}).get("assetId")
        for record in store.values()
        if record.get("typeName") == "shape" and record.get("type") == "image"
    }
    for asset_id in removed_assets - still_used:
        store.pop(asset_id, None)
    return removed_shapes


def main() -> int:
    parser = argparse.ArgumentParser(description="Insert an Image2 output into Cowart and focus the visible canvas.")
    parser.add_argument("--image", required=True, help="Absolute path to the generated bitmap.")
    parser.add_argument("--cowart-url", default=DEFAULT_COWART_URL, help="Running Cowart URL.")
    parser.add_argument("--project-dir", help="Codex project directory that owns canvas/.")
    parser.add_argument("--canvas-dir", help="Canvas directory override.")
    parser.add_argument("--workflow", choices=["generate", "edit"], default="generate")
    parser.add_argument("--page-policy", choices=["auto", "new", "current"], default="auto")
    parser.add_argument("--page-name", help="Name for a fresh Cowart page.")
    parser.add_argument("--anchor-shape-id", help="Shape id to place beside for edits.")
    parser.add_argument("--placement", choices=["right", "left", "below", "center"], default="center")
    parser.add_argument("--margin", type=float, default=40)
    parser.add_argument("--display-width", type=float)
    parser.add_argument("--display-height", type=float)
    parser.add_argument("--target-size", help="Requested output size or aspect ratio, such as 1024x1536.")
    parser.add_argument("--reference-size", help="Reference image size/aspect ratio; used when no target size is given.")
    parser.add_argument("--strict-target-ratio", action="store_true", help="Fail instead of inserting if the bitmap does not match the requested/reference ratio.")
    parser.add_argument("--file-name", help="Destination asset filename.")
    parser.add_argument("--annotation-screenshot", help="Annotation screenshot filename for metadata.")
    parser.add_argument("--alt-text", default="Image2 output inserted into Cowart")
    parser.add_argument("--preserve-holder-content", action="store_true", help="Do not replace previous image children in a selected holder.")
    parser.add_argument("--no-focus", action="store_true", help="Do not update Cowart view-state.")
    parser.add_argument("--viewport-width", type=float, default=900)
    parser.add_argument("--viewport-height", type=float, default=650)
    args = parser.parse_args()

    image_path = Path(args.image).resolve()
    if not image_path.is_file():
        raise SystemExit(f"Image file not found: {image_path}")
    cowart_url = args.cowart_url.rstrip("/")
    project_dir = Path(args.project_dir).resolve() if args.project_dir else None
    canvas_dir_arg = Path(args.canvas_dir).resolve() if args.canvas_dir else None
    target_ratio = parse_size(args.target_size) or parse_size(args.reference_size)

    canvas_payload = http_json("GET", f"{cowart_url}/api/canvas")
    snapshot = canvas_payload.get("snapshot") or canvas_payload
    if not snapshot or not snapshot.get("store") or not snapshot.get("schema"):
        raise SystemExit("Cowart canvas is empty or uninitialized. Open the Cowart page once, then retry.")
    store: dict[str, Any] = snapshot["store"]
    selected_ids = selected_shape_ids(cowart_url)
    selected_shapes = [store[item] for item in selected_ids if item in store]
    selected_holder = selected_shapes[0] if len(selected_shapes) == 1 and is_ai_holder(selected_shapes[0]) else None

    source_width, source_height = image_size(image_path)
    canvas_dir = infer_canvas_dir(canvas_payload, project_dir, canvas_dir_arg)
    if project_dir and not canvas_dir_arg:
        expected_canvas_dir = (project_dir / "canvas").resolve()
        if canvas_dir.resolve() != expected_canvas_dir:
            raise SystemExit(
                "Running Cowart service is bound to a different project canvas: "
                f"{canvas_dir}. Expected {expected_canvas_dir}. Restart/open Cowart "
                "for the active project before inserting."
            )
    mismatch = ratio_mismatch(source_width, source_height, target_ratio)
    if mismatch is not None and args.strict_target_ratio:
        raise SystemExit(
            f"Generated bitmap ratio {source_width}x{source_height} does not match "
            f"target/reference ratio {target_ratio[0]:g}x{target_ratio[1]:g} "
            f"(delta {mismatch:.1%}). Regenerate with the requested/reference size "
            "before inserting into Cowart."
        )

    page_id: str
    parent_id: str
    x: float
    y: float
    display_width: float
    display_height: float
    focus_items: list[dict[str, float]]
    removed_holder_shapes: list[str] = []
    shape_meta: dict[str, Any] = {}

    if selected_holder:
        page_id = find_page_for_shape(store, selected_holder["id"]) or next(
            record["id"] for record in store.values() if record.get("typeName") == "page"
        )
        holder_bounds = record_bounds(selected_holder, store)
        display_width = float(selected_holder.get("props", {}).get("w") or holder_bounds["w"])
        display_height = float(selected_holder.get("props", {}).get("h") or holder_bounds["h"])
        if not args.preserve_holder_content:
            removed_holder_shapes = remove_holder_images(store, selected_holder["id"])
        if selected_holder.get("type") == "frame":
            parent_id = selected_holder["id"]
            x, y = 0.0, 0.0
        else:
            parent_id = selected_holder.get("parentId") or page_id
            x, y = float(selected_holder.get("x") or 0), float(selected_holder.get("y") or 0)
        shape_meta["cowartGeneratedForAiImageHolder"] = selected_holder["id"]
        focus_items = [holder_bounds]
    else:
        use_new_page = args.page_policy == "new" or (args.page_policy == "auto" and args.workflow == "generate")
        if use_new_page:
            page_id = create_page(store, args.page_name)
            parent_id = page_id
            display_width, display_height = target_display_size(
                source_width,
                source_height,
                args.display_width,
                args.display_height,
                target_ratio,
            )
            x, y = 0.0, 0.0
            focus_items = [{"x": x, "y": y, "w": display_width, "h": display_height}]
            shape_meta["cowartGeneratedStandalone"] = True
        else:
            anchor_id = non_empty(args.anchor_shape_id)
            if not anchor_id:
                usable_selected = [
                    shape for shape in selected_shapes if shape.get("type") in {"image", "frame", "geo"}
                ]
                if len(usable_selected) == 1:
                    anchor_id = usable_selected[0]["id"]
            anchor = store.get(anchor_id) if anchor_id else None
            page_id = (
                (find_page_for_shape(store, anchor["id"]) if anchor else None)
                or next(record["id"] for record in store.values() if record.get("typeName") == "page")
            )
            parent_id = anchor.get("parentId") if anchor and store.get(anchor.get("parentId"), {}).get("typeName") == "page" else page_id
            if anchor and not args.display_width and not args.display_height:
                anchor_bounds = record_bounds(anchor, store)
                display_width, display_height = anchor_bounds["w"], anchor_bounds["h"]
            else:
                display_width, display_height = target_display_size(
                    source_width,
                    source_height,
                    args.display_width,
                    args.display_height,
                    target_ratio,
                )
            placement = "right" if args.placement == "center" and anchor else args.placement
            if placement == "center":
                x, y, anchor_bounds = 0.0, 0.0, None
            else:
                x, y, anchor_bounds = choose_clear_position(
                    store, page_id, parent_id, display_width, display_height, anchor, placement, args.margin
                )
            shape_meta["cowartGeneratedFromAnnotationEdit" if args.workflow == "edit" else "cowartGeneratedStandalone"] = True
            if anchor_id:
                shape_meta["cowartAnnotationSourceShapeId"] = anchor_id
            if args.annotation_screenshot:
                shape_meta["cowartAnnotationScreenshot"] = Path(args.annotation_screenshot).name
            focus_items = [{"x": x, "y": y, "w": display_width, "h": display_height}]
            if anchor_bounds:
                focus_items.append(anchor_bounds)

    page_dir = page_dir_name(page_id)
    assets_dir = canvas_dir / "pages" / page_dir / "assets"
    assets_dir.mkdir(parents=True, exist_ok=True)
    requested_file = args.file_name or image_path.name
    file_name, asset_path = unique_file_path(assets_dir, requested_file)
    shutil.copy2(image_path, asset_path)

    seed = sanitize_id_part(file_name)
    asset_id = unique_record_id(store, "asset", seed)
    shape_id = unique_record_id(store, "shape", seed)
    siblings = [record for record in store.values() if record.get("typeName") == "shape" and record.get("parentId") == parent_id]
    mime_type = mimetypes.guess_type(file_name)[0] or "application/octet-stream"

    store[asset_id] = {
        "id": asset_id,
        "typeName": "asset",
        "type": "image",
        "props": {
            "name": file_name,
            "src": page_asset_url(page_id, file_name),
            "w": source_width,
            "h": source_height,
            "fileSize": image_path.stat().st_size,
            "mimeType": mime_type,
            "isAnimated": False,
        },
        "meta": {"generatedBy": "image2-ai"},
    }
    store[shape_id] = {
        "x": x,
        "y": y,
        "rotation": 0,
        "isLocked": False,
        "opacity": 1,
        "meta": shape_meta,
        "id": shape_id,
        "type": "image",
        "props": {
            "w": display_width,
            "h": display_height,
            "assetId": asset_id,
            "playing": True,
            "url": "",
            "crop": None,
            "flipX": False,
            "flipY": False,
            "altText": args.alt_text,
        },
        "parentId": parent_id,
        "index": next_index(siblings),
        "typeName": "shape",
    }

    save_result = http_json("PUT", f"{cowart_url}/api/canvas", snapshot)
    focus_bounds = union_bounds(focus_items)
    view_state = None if args.no_focus else set_view_state(
        cowart_url,
        page_id,
        focus_bounds,
        args.viewport_width,
        args.viewport_height,
    )

    result = {
        "ok": True,
        "cowartUrl": cowart_url,
        "canvasDir": str(canvas_dir),
        "pageId": page_id,
        "parentId": parent_id,
        "shapeId": shape_id,
        "assetId": asset_id,
        "assetPath": str(asset_path),
        "assetUrl": store[asset_id]["props"]["src"],
        "sourceImagePath": str(image_path),
        "imageSize": {"width": source_width, "height": source_height},
        "targetRatioMismatch": mismatch,
        "bounds": {"x": x, "y": y, "w": display_width, "h": display_height},
        "focusBounds": focus_bounds,
        "viewState": view_state,
        "selectedHolderId": selected_holder["id"] if selected_holder else None,
        "removedHolderShapes": removed_holder_shapes,
        "save": save_result,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
