---
name: image2-ai
description: >-
  Use when the user wants AI image generation or AI image editing through the
  user's private Image2 relay, including requests such as AI image editing,
  AI retouching, Image2, generating an image, editing a provided image,
  changing clothes/background/colors, removing or adding objects, using a
  reference image, or continuing from the previous generated image. This skill
  always uses the relay-backed Adobe Image2 model through the configured
  OpenAI-compatible model name `gpt-image-2`; it must not use local Photoshop,
  rembg, segmentation, compositing, or other non-Image2 workflows unless the
  user explicitly asks for local/non-AI pixel-preservation. After every
  successful generation or edit, it must complete the Cowart canvas handoff
  when the Cowart plugin/canvas is available: start/open Cowart visibly, insert
  the final image into a selected AI image holder or a clean visible canvas
  page, focus the canvas on the result, verify insertion, and report the Cowart
  shape/asset result.
---

# Image2 AI

## Purpose

Use the user's private relay to access the Adobe Image2 image model for AI
image generation and AI image editing.

The relay is OpenAI-compatible, and the configured model name remains
`gpt-image-2`. Do not rename the model to `adobe-image2` or any other value
unless the user explicitly changes the relay configuration.

Keep credentials out of skill files. Read credentials only from environment
variables or the local private config file.

## Core Rule

Always use Image2 for this skill.

Even when the user says the person, face, body, pose, background, identity, or
other regions must stay unchanged, express that constraint in the Image2 prompt.
Do not automatically call local segmentation, rembg, Photoshop, local
compositing, or other non-Image2 workflows.

Use local/non-AI pixel-preservation only if the user explicitly asks for it with
language such as "use local tools", "do not let AI redraw the person", "keep
the original person pixels", "composite the original person back", or "use
non-AI pixel preservation".

## Credential Rules

Never ask the user to paste secrets into chat unless there is no safer option.
Never write real API keys or relay URLs into `SKILL.md`, `agents/openai.yaml`,
committed project files, or final answers.

Read configuration in this order:

1. Optional local private config file:
   - `%USERPROFILE%\.codex\private\image2-ai.env`
2. Explicit per-run overrides:
   - `--api-base <url>` on `scripts/image2_ai.py`
   - `IMAGE2_API_BASE_OVERRIDE`
3. Process/user/machine environment variables as a fallback:
   - `IMAGE2_API_KEY`
   - `IMAGE2_API_BASE` or `IMAGE2_API_BASE_URL`
   - `IMAGE2_API_MODEL` (default `gpt-image-2`)

The private config file uses simple `KEY=VALUE` lines and must remain local.
Example keys are documented in `references/configuration.md`; do not include
real secret values there.

When diagnosing configuration, run:

```bash
python scripts/image2_ai.py --self-test
```

It prints the normalized base URL, model name, and whether values came from the
private config, an override, or the environment without printing the API key.

## Workflow

1. Decide operation:
   - Use `generate` when the user wants a new image and did not provide a source
     image or refer to the previous generated image.
   - Use `edit` when the user provides an image, mentions a reference image, or
     asks to revise the previous generated image.
2. Build a strong Image2 prompt:
   - Preserve the user's requested subject, style, constraints, and edits.
   - For edits, clearly state what should change and what must remain unchanged.
   - If the user says the person must not change, say that in the prompt:
     preserve face, hair, identity, body, pose, hands, expression, lighting,
     background, composition, or any other requested unchanged regions.
   - For photo edits, inspect the image for visible platform watermarks,
     usernames, IDs, timestamps, stickers, or app logos. Unless the user asks to
     keep them, add prompt language to remove these marks and reconstruct the
     underlying scene naturally.
   - Add highest-quality, photorealistic, natural-lighting intent when relevant.
   - Do not invent arbitrary low-resolution sizes. When the user specifies an
     orientation, aspect ratio, print format, poster/banner/card shape, or exact
     dimensions, carry that sizing intent into the script call.
3. Call the relay with the bundled script:
   - `python scripts/image2_ai.py generate --prompt "..."`
   - `python scripts/image2_ai.py edit --prompt "..." --image path\to\image.png`
   - Add `--out-dir <folder>` when a specific output folder is needed.
   - For new generations with a requested aspect ratio or orientation, use
     `--size auto --target-size <ratio-or-size>` so the script requests the
     largest supported 4K-level bitmap while preserving the requested ratio.
     The script normalizes dimensions to multiples of `16`, keeps the longest
     edge at or below `3840`, and keeps total pixels at or below `8,294,400`.
     Example: vertical `9x16` resolves to `2160x3840`.
   - Do not use small explicit sizes such as `1024x1792` for poster, print, or
     high-resolution requests unless the user explicitly asks for that exact
     size. Prefer `--size auto --target-size 9x16` for a vertical poster.
   - For edits, the script default `--size auto` preserves the input aspect
     ratio and requests the largest 4K-level size allowed by the relay
     (`8,294,400` pixels, with a longest edge up to `3840`).
   - Use the default `--timeout 600` for slow generations.
   - Use the default `--retries 2`; do not increase it unless the user asks.
   - Use `--api-base <url>` only for a one-off relay override.
4. Save user-facing outputs in the current task's output folder when available.
5. If editing "the previous image", use the most recent Image2 output file from
   the current conversation/task as the input image. If several candidates
   exist and the user refers to a specific one, choose that file.
6. If the user requested exact original dimensions, verify the final image size.
   If needed, create a same-dimensions copy without changing the requested
   content.
   If the relay ignores a requested size/aspect ratio, treat the output as
   incomplete and regenerate with a stricter prompt plus `--size auto
   --target-size <ratio-or-size>` before handing off or finalizing.
7. Treat Cowart insertion as part of the normal completion criteria, not as an
   optional nicety:
   - Use the Cowart image generation/open-canvas skill instructions when they
     are available.
   - Before insertion, confirm the running Cowart service is bound to the active
     Codex project. Check `GET http://127.0.0.1:43217/api/canvas`; the returned
     canvas path must belong to the active project directory. If it points to a
     sibling or old project, restart/open Cowart for the active project before
     inserting.
   - If the Cowart service is not running or is bound to the wrong project, use
     the Cowart open-canvas skill and start it for the active Codex project.
     Then open `http://127.0.0.1:43217/` in the in-app browser when browser
     control is available.
   - Always make the in-app browser visible and navigate an existing/new tab to
     the running Cowart URL after insertion. The user should not have to hunt
     for the canvas to confirm the result.
   - Read `http://127.0.0.1:43217/api/selection` or the Cowart MCP selection
     tool before inserting. If exactly one selected shape is an AI image holder,
     place the final output into that holder according to the Cowart holder
     contract. If no holder is selected, insert the output into a clear area of
     the current page.
   - For ordinary new image generation with no selected holder, prefer a fresh
     Cowart page over reusing a page that already contains prior outputs. Name
     the page from the task when useful. This prevents old and new requests from
     piling up on the same canvas.
   - Treat Cowart as an infinite canvas by default, not as a mandatory
     frame-first workflow. Do not ask the user to draw/select an AI image holder
     unless they explicitly want a precise slot, have already selected a holder,
     or the task requires exact frame placement.
   - For annotation-driven edits or explicit comparison requests, keep the
     revised output beside the annotated/source image on the same page, because
     side-by-side comparison matters more than a clean page.
   - Preserve requested sizing: if the user specifies width/height or aspect
     ratio, pass that target ratio to Cowart insertion. If editing from or
     following a reference image and the user did not specify another size,
     preserve the reference image aspect ratio. This does not require drawing a
     holder; the handoff can size the inserted canvas image directly. Do not
     stretch a generated image into a mismatched frame.
   - If the canvas API returns an empty canvas snapshot, open the Cowart page
     and let tldraw initialize. If needed, create/select an AI image holder via
     the Cowart UI/tool so the page snapshot exists, then retry insertion. Do
     not stop at "saved file" just because the first insert attempt saw an empty
     canvas.
   - Prefer `scripts/cowart_handoff.py` for Cowart placement after Image2
     generation. It handles selected AI holders, fresh pages, reference/target
     ratios, page-local assets, and view-state focusing. Run it from the active
     Codex project directory or pass `--project-dir <active-project-dir>` so it
     can reject a Cowart service that is bound to an old canvas. This avoids
     rewriting fragile PowerShell/Node one-off scripts.
     Example for a new generation:

     ```bash
     python scripts/cowart_handoff.py --image <generated.png> --project-dir <active-project-dir> --workflow generate --page-policy auto --page-name "<short task name>" --target-size 9x16 --strict-target-ratio
     ```

     Example for an annotation edit beside a known source image:

     ```bash
     python scripts/cowart_handoff.py --image <edited.png> --workflow edit --page-policy current --anchor-shape-id <shape-id> --annotation-screenshot <screenshot.png>
     ```

     When a target size or reference image ratio matters, include
     `--strict-target-ratio`; if the generated bitmap ratio does not match, fix
     the Image2 generation/edit first instead of stretching it in Cowart.
   - After a successful handoff, explicitly open the in-app browser. Do not
     assume `cowart_handoff.py` alone will pop the right-side browser visible;
     it updates canvas data and view-state, then browser control must set
     visibility and navigate/focus the Cowart URL. If browser control is not
     available, report the Cowart URL and say that the in-app browser could not
     be opened automatically.

   - If `cowart_handoff.py` is unavailable, prefer the Cowart MCP
     `insert_cowart_image` tool. If neither is available, use the documented
     Cowart HTTP APIs, but use ES modules for inline Node (`node
     --input-type=module` with `import ...`) or Python `urllib`; do not mix
     CommonJS `require()` with top-level `await`.
   - If the request edited an image from a Cowart annotation screenshot or a
     selected Cowart image, place the revised output beside the original rather
     than replacing, hiding, moving, or deleting the original.
   - If Cowart insertion cannot be completed after starting/opening Cowart,
     checking selection, initializing an empty canvas, and one retry, return the
     saved image path and explicitly say Cowart insertion failed/skipped with the
     concrete reason. Do not silently omit the Cowart step.
8. Before the final answer, verify the Cowart handoff:
   - Confirm a saved local output path exists.
   - Confirm the image dimensions when relevant.
   - Confirm the Cowart inserted shape id, page id, asset path/URL, and focused
     view-state when insertion succeeds, or the exact failure reason when it
     does not.
9. Return the final image path and the Cowart placement result together.

## Failure Handling

- If credentials are missing, say exactly which variable or private config entry
  is missing and explain where to set it. Do not ask for the key in chat by
  default.
- If the AI request fails for a relay, server, auth, model, or transient reason,
  let `scripts/image2_ai.py` retry the same request twice. If the final attempt
  still fails, tell the user the exact error and stop the workflow.
- Do not produce a substitute image with built-in image generation, Photoshop,
  local filters, rembg, segmentation, compositing, or another tool after Image2
  exhausts retries unless the user explicitly asks for that fallback.
- If the relay rejects an endpoint, inspect the error and adjust only endpoint
  normalization or payload shape. Do not guess a new model name unless the user
  supplies it.
- If the model returns multiple images, save all candidates and identify the
  best one for the user's request.
- If an edit result ignores the source image, try a stricter Image2 prompt
  emphasizing preservation before giving up.
- If a watermark or platform badge remains in the output, treat the edit as
  incomplete. Retry with explicit Image2 prompt wording to remove visible
  watermarks, platform logos, usernames, IDs, timestamps, and app badges while
  reconstructing the underlying scene naturally.
