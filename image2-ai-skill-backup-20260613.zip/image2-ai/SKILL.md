---
name: image2-ai
description: >-
  Use when the user explicitly wants AI/Image2 image generation or AI/Image2
  image editing through the user's private relay, including broad natural
  phrases such as "AI帮我生成图片", "AI画一张", "生图", "出一张图",
  "做一张图", "用AI做图", "用Image2", "调用Image 2", "参考这张图生成",
  "AI改这张图", "用AI调整参考图", "在上一张基础上改", "继续改刚才那张",
  "上一版再调整", "把上图改成...", or similar requests that mention AI,
  Image2/Image 2, generation, reference-image creation, or continuing from the
  previous generated image. Do not use for ordinary photo retouching requests
  such as "修图", "帮我修图", "P图", "精修", or Photoshop/PS retouching
  unless the same user turn explicitly asks for AI, Image2/Image 2, or an image
  model; those plain retouching requests belong to the Photoshop retouching
  skill.
---

# Image2 AI

## Purpose

Use the user's private Image2 relay for high-quality AI image generation and
image editing. Keep credentials out of the skill files; read them only from
environment variables or a local private config file.

This skill is intentionally complementary to `image2-editor`:

- Plain "修图", "帮我修图", "P图", "精修", "PS修图", or Photoshop-only work
  stays with the Photoshop retouching skill.
- Requests that explicitly mention AI, Image2/Image 2, image models, generating
  pictures, reference-image creation, or continuing/editing a previous AI result
  use this skill.

## Trigger Interpretation

Do not require the user to say one exact phrase. Treat these as Image2 requests:

- New image generation: "AI帮我生成...", "帮我画...", "生图", "出图",
  "做一张图", "生成一张海报/头像/场景/产品图", "用AI做图", "Image2生成".
- Reference-image generation: "参考这张生成", "按这个风格做一张",
  "用这张当参考", "根据这张图出一版".
- Editing an image: "AI改这张", "用AI调整", "把这个地方改成...",
  "换背景", "改颜色", "去掉/增加某物", "保持主体只改环境".
- Continuing from the previous result: "上一张再改一下", "继续改刚才那张",
  "上图不行, 把...改掉", "刚才那版...", "第二张基础上...", "再来一版".

When a request is ambiguous and could mean normal Photoshop retouching, prefer
Photoshop unless the same turn includes AI/Image2/image-model language.

## Credential Rules

Never ask the user to paste secrets into chat unless there is no safer option.
Never write real API keys or relay URLs into `SKILL.md`, `agents/openai.yaml`,
committed project files, or final answers.

Read configuration in this order. The private config is intentionally preferred
over general environment variables so this skill does not accidentally reuse
base URLs from Photoshop or other image workflows:

1. Optional local private config file:
   - `%USERPROFILE%\.codex\private\image2-ai.env`
2. Explicit per-run overrides:
   - `--api-base <url>` on `scripts/image2_ai.py`
   - `IMAGE2_API_BASE_OVERRIDE`
3. Process/user/machine environment variables as a fallback:
   - `IMAGE2_API_KEY`
   - `IMAGE2_API_BASE` or `IMAGE2_API_BASE_URL`
   - `IMAGE2_API_MODEL` (default `gpt-image-2`)

The private config file uses simple `KEY=VALUE` lines and must remain local.
Example keys are documented in `references/configuration.md`; do not include
real secret values there.

When diagnosing configuration, run `python scripts/image2_ai.py --self-test`.
It prints the normalized base URL and whether it came from the private config,
an override, or the environment without printing the API key.

## Workflow

1. Decide operation:
   - Use `generate` when the user wants a new image and did not provide a source
     image or refer to the previous generated image.
   - Use `edit` when the user provides an image, mentions a reference image, or
     asks to revise the previous generated image.
2. Retry policy:
   - If the AI relay fails for a non-local reason, retry the same AI request up
     to 2 more times.
   - If all 3 attempts fail, stop and report the failure.
   - Do not switch to a different image path, built-in image tool, Photoshop
     workflow, or local hard fallback after those retries unless the user
     explicitly asks.
3. Build a strong prompt:
   - Preserve the user's requested subject, style, constraints, and edits.
   - For photo edits, inspect the image for visible platform watermarks,
     usernames, IDs, timestamps, stickers, or app logos. Unless the user asks to
     keep them, add prompt language to remove these marks and reconstruct the
     underlying scene naturally without changing the protected subject.
   - Add "highest quality" intent naturally.
   - Do not force a size. Let the model choose unless the user specifies size,
     aspect ratio, or an exact output requirement.
4. Use the bundled script when calling the relay:
   - `python scripts/image2_ai.py generate --prompt "..."`
   - `python scripts/image2_ai.py edit --prompt "..." --image path\to\image.png`
   - Add `--out-dir <folder>` when a specific output folder is needed.
   - Use the default `--timeout 600` for slow 4K generations; raise it only if
     the user explicitly says their relay needs longer.
   - Use the default `--retries 2`; do not increase it unless the user asks.
   - Use `--api-base <url>` only for a one-off relay override.
5. Save user-facing outputs in the current task's output folder when available.
6. If editing "the previous image", use the most recent Image2 output file from
   the current conversation/task as the input image. If several candidates exist
   and the user refers to a specific one, choose that file.
7. Return the final image path and, when useful, a short note describing what was
   generated or changed.

## Person-Preserving Background Edits

Use a two-pass workflow when the user says the person/portrait/face/body must
not move or change, for example "人物不动", "人物不要调整", "只改背景",
"脸不要变", or "保持人像原样".

Do not promise pixel-perfect identity from a normal Image2 edit. Image2 can
still subtly redraw the face, clothing, shoes, hair, or hands even when the
prompt says not to. Prefer this workflow:

1. Run an Image2 edit for the whole image to create the desired background,
   atmosphere, or color grade. Strongly prompt the model to avoid halos,
   ghosting, pasted-layer edges, or transition shadows around the person.
2. Segment the person from the original image with `rembg` using
   `u2net_human_seg.onnx`.
3. Composite original-person pixels over the Image2 result with
   `scripts/preserve_person_composite.py`.
4. Inspect the output around shoes, legs, hands, shoulders, hair, and any gap
   between limbs. These areas expose bad masks first.
5. Inspect common watermark areas, especially lower-left, lower-right, top
   corners, and app-logo badges. If a watermark, username, numeric ID, timestamp,
   or platform label remains, remove it with a stricter Image2 prompt or a local
   repair pass before delivery.
6. If the edge looks like a transparent shadow, gray fringe, or ghost layer,
   rerun the composite with a higher `--threshold`, higher `--erode`, or lower
   `--feather`. Do not deliver a result with a visible mask blob.

Run the compositor like:

```bash
python scripts/preserve_person_composite.py \
  --original path\to\original.jpg \
  --edited path\to\image2-background.png \
  --output path\to\final.png
```

By default it forces `rembg` to use `CPUExecutionProvider`; this avoids provider
selection failures seen on Windows. It uses only the mask from `rembg`, not the
RGBA colors, because `rembg` transparent previews can contain gray/black fringe
colors. The final person's color pixels come from the original image.

### Model Setup

The person-preserving compositor requires:

- Python packages: `rembg` and `onnxruntime`
- Model file: `%USERPROFILE%\.u2net\u2net_human_seg.onnx`

If the model is missing and automatic download fails, ask the user to download
`u2net_human_seg.onnx` manually and place it at the path above. If loading the
model fails with `system error number 13`, verify that Python can read the file
and force the CPU provider. Direct `onnxruntime.InferenceSession(...,
providers=["CPUExecutionProvider"])` is the quickest diagnosis.

## Quality Defaults

- Request highest practical visual quality.
- For edits of real photos, remove visible platform watermarks, usernames,
  numeric IDs, timestamps, and app badges by default unless the user explicitly
  asks to preserve them. Prompt for clean background reconstruction where the
  marks were, not cropping or smearing.
- Do not downscale or compress unless the user asks.
- Do not manually set image dimensions by default; let Image2 select the
  suitable size.
- Preserve important identity, composition, product details, text, logos, and
  reference-image structure when the user asks for editing rather than a remake.
- For edits, keep unchanged regions stable unless the user asks for a broader
  redesign.

## Failure Handling

- If credentials are missing, say exactly which variable or private config entry
  is missing and explain where to set it. Do not ask for the key in chat by
  default.
- If the AI request fails for a non-local relay/server/auth/model reason, let
  `scripts/image2_ai.py` retry the same request twice. If the final attempt
  still fails, tell the user the exact error and stop the image workflow.
- Do not produce a substitute image with the built-in image generator,
  Photoshop, local filters, or another tool after Image2 exhausts its retries,
  unless the user explicitly asks for that fallback.
- If the relay rejects an endpoint, inspect the error and adjust only endpoint
  normalization or payload shape. Do not guess a new model name unless the user
  supplies it.
- If the model returns multiple images, save all candidates and identify the
  best one for the user's request.
- If an edit result ignores the source image, try a stricter prompt emphasizing
  preservation before giving up.
- If a watermark or platform badge remains in the output, treat the edit as
  incomplete. Retry with explicit removal wording such as: "Remove all visible
  watermarks, platform logos, usernames, IDs, timestamps, and app badges; cleanly
  reconstruct the underlying sea/sky/railing/background texture; do not crop;
  do not alter the person."
- If a person-preserving composite has a visible transition layer around the
  subject, the mask is too broad or too soft. Use `u2net_human_seg`, tighten the
  alpha, reduce feathering, and inspect shoes/legs before returning the image.
