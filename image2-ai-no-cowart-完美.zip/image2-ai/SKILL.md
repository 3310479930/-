---
name: image2-ai
description: >-
  Use when the user wants AI image generation or AI image editing through the
  user's private Image2 relay, including requests such as AI image editing,
  AI retouching, Image2, generating an image, editing a provided image,
  changing clothes/background/colors, removing or adding objects, using a
  reference image, or continuing from the previous generated image. This skill
  always uses the relay-backed Adobe Image2 model through the configured
  OpenAI-compatible model name `gpt-image-2`; it must not use local Photoshop,
  rembg, segmentation, compositing, or other non-Image2 workflows unless the
  user explicitly asks for local/non-AI pixel-preservation. After every
  successful generation or edit, save the resulting image file locally and
  report the saved path; do not automatically insert images into Cowart or any
  infinite canvas unless the user explicitly asks for that separate handoff.
---

# Image2 AI

## Purpose

Use the user's private relay to access the Adobe Image2 image model for AI
image generation and AI image editing.

The relay is OpenAI-compatible, and the configured model name remains
`gpt-image-2`. Do not rename the model to `adobe-image2` or any other value
unless the user explicitly changes the relay configuration.

Keep credentials out of skill files. Read credentials only from environment
variables or the local private config file.

## Core Rule

Always use Image2 for this skill.

Even when the user says the person, face, body, pose, background, identity, or
other regions must stay unchanged, express that constraint in the Image2 prompt.
Do not automatically call local segmentation, rembg, Photoshop, local
compositing, or other non-Image2 workflows.

Use local/non-AI pixel-preservation only if the user explicitly asks for it with
language such as "use local tools", "do not let AI redraw the person", "keep
the original person pixels", "composite the original person back", or "use
non-AI pixel preservation".

## Credential Rules

Never ask the user to paste secrets into chat unless there is no safer option.
Never write real API keys or relay URLs into `SKILL.md`, `agents/openai.yaml`,
committed project files, or final answers.

Read configuration in this order:

1. Optional local private config file:
   - `%USERPROFILE%\.codex\private\image2-ai.env`
2. Explicit per-run overrides:
   - `--api-base <url>` on `scripts/image2_ai.py`
   - `IMAGE2_API_BASE_OVERRIDE`
3. Process/user/machine environment variables as a fallback:
   - `IMAGE2_API_KEY`
   - `IMAGE2_API_BASE` or `IMAGE2_API_BASE_URL`
   - `IMAGE2_API_MODEL` (default `gpt-image-2`)

The private config file uses simple `KEY=VALUE` lines and must remain local.
Example keys are documented in `references/configuration.md`; do not include
real secret values there.

When diagnosing configuration, run:

```bash
python scripts/image2_ai.py --self-test
```

It prints the normalized base URL, model name, and whether values came from the
private config, an override, or the environment without printing the API key.

## Workflow

1. Decide operation:
   - Use `generate` when the user wants a new image and did not provide a source
     image or refer to the previous generated image.
   - Use `edit` when the user provides an image, mentions a reference image, or
     asks to revise the previous generated image.
2. Build a strong Image2 prompt:
   - Preserve the user's requested subject, style, constraints, and edits.
   - For edits, clearly state what should change and what must remain unchanged.
   - If the user says the person must not change, say that in the prompt:
     preserve face, hair, identity, body, pose, hands, expression, lighting,
     background, composition, or any other requested unchanged regions.
   - For photo edits, inspect the image for visible platform watermarks,
     usernames, IDs, timestamps, stickers, or app logos. Unless the user asks to
     keep them, add prompt language to remove these marks and reconstruct the
     underlying scene naturally.
   - Add highest-quality, photorealistic, natural-lighting intent when relevant.
   - Do not invent arbitrary low-resolution sizes. When the user specifies an
     orientation, aspect ratio, print format, poster/banner/card shape, or exact
     dimensions, carry that sizing intent into the script call.
3. Call the relay with the bundled script:
   - `python scripts/image2_ai.py generate --prompt "..."`
   - `python scripts/image2_ai.py edit --prompt "..." --image path\to\image.png`
   - Add `--out-dir <folder>` when a specific output folder is needed.
   - For new generations with a requested aspect ratio or orientation, use
     `--size auto --target-size <ratio-or-size>` so the script requests the
     largest supported 4K-level bitmap while preserving the requested ratio.
     The script normalizes dimensions to multiples of `16`, keeps the longest
     edge at or below `3840`, and keeps total pixels at or below `8,294,400`.
     Example: vertical `9x16` resolves to `2160x3840`.
   - Do not use small explicit sizes such as `1024x1792` for poster, print, or
     high-resolution requests unless the user explicitly asks for that exact
     size. Prefer `--size auto --target-size 9x16` for a vertical poster.
   - For edits, the script default `--size auto` preserves the input aspect
     ratio and requests the largest 4K-level size allowed by the relay
     (`8,294,400` pixels, with a longest edge up to `3840`).
   - Use the default `--timeout 600` for slow generations.
   - Use the default `--retries 2`; do not increase it unless the user asks.
   - Use `--api-base <url>` only for a one-off relay override.
4. Save user-facing outputs in the current task's output folder when available.
5. If editing "the previous image", use the most recent Image2 output file from
   the current conversation/task as the input image. If several candidates
   exist and the user refers to a specific one, choose that file.
6. If the user requested exact original dimensions, verify the final image size.
   If needed, create a same-dimensions copy without changing the requested
   content.
   If the relay ignores a requested size/aspect ratio, treat the output as
   incomplete and regenerate with a stricter prompt plus `--size auto
   --target-size <ratio-or-size>` before finalizing.
7. Do not automatically open, start, or write to Cowart or any infinite canvas.
   Treat canvas placement as a separate workflow only when the user explicitly
   asks for it.
8. Before the final answer:
   - Confirm each saved local output path exists.
   - Confirm the image dimensions when the user requested a size, aspect ratio,
     or exact original dimensions.
   - For batches, give clear names or a folder/zip path so the user can find
     the outputs without reading timestamps.
9. Return the final image path(s), and mention any relevant size verification.

## Failure Handling

- If credentials are missing, say exactly which variable or private config entry
  is missing and explain where to set it. Do not ask for the key in chat by
  default.
- If the AI request fails for a relay, server, auth, model, or transient reason,
  let `scripts/image2_ai.py` retry the same request twice. If the final attempt
  still fails, tell the user the exact error and stop the workflow.
- Do not produce a substitute image with built-in image generation, Photoshop,
  local filters, rembg, segmentation, compositing, or another tool after Image2
  exhausts retries unless the user explicitly asks for that fallback.
- If the relay rejects an endpoint, inspect the error and adjust only endpoint
  normalization or payload shape. Do not guess a new model name unless the user
  supplies it.
- If the model returns multiple images, save all candidates and identify the
  best one for the user's request.
- If an edit result ignores the source image, try a stricter Image2 prompt
  emphasizing preservation before giving up.
- If a watermark or platform badge remains in the output, treat the edit as
  incomplete. Retry with explicit Image2 prompt wording to remove visible
  watermarks, platform logos, usernames, IDs, timestamps, and app badges while
  reconstructing the underlying scene naturally.
